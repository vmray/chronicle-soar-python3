from .integration_kit import VMRaySubmissionKit, SubmissionResult
