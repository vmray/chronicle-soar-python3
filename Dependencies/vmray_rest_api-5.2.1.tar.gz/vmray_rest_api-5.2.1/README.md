# VMRay REST API

This package contains the VMRay REST API client library, the VMRay Integration Kit and examples of use.
